package group.e.eraktadaan.controllers;


import group.e.eraktadaan.entities.*;
//import group.e.eraktadaan.entities.Contactus;
//import group.e.eraktadaan.repository.ContactusRepository;
import group.e.eraktadaan.repository.BloodbankRepository;
import group.e.eraktadaan.repository.DonationRepository;
import group.e.eraktadaan.repository.DonorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class DonorController {

    @Autowired
    DonorRepository donorRepository;

    @PostMapping("/registerdonor")
    Map<String, Object> registerDonor(@RequestBody Map<String, Object> request) {
        Map<String, Object> result = new HashMap<>();

        String name = (String) request.get("name");
        String address = (String) request.get("address");
        String mobileno = (String) request.get("mobileno");
        String username = (String) request.get("username");
        String password = (String) request.get("password");
        String dob = (String) request.get("dob");
        String bloodgroup = (String) request.get("bloodgroup");
        String rhfactor = (String) request.get("rhfactor");

        Donor a = new Donor();
        a.setDonorname(name);
        a.setDonoraddress(address);
        a.setMobileno(mobileno);
        a.setUsername(username);
        a.setPassword(password);
        a.setDob(dob);
        a.setBloodgroup(bloodgroup);
        a.setRhfactor(rhfactor);
        a.setActive("Y");
        a.setDobnotification("Y");
        a.setCandonate("Y");


        donorRepository.save(a);

        result.put("result", true);
        result.put("donor", a);

        return result;
    }

    @PostMapping("/donorlogin")
    Map<String, Object> login(@RequestBody Map<String, Object> request) {
        Map<String, Object> result = new HashMap<>();

        String username = (String) request.get("username");
        String password = (String) request.get("password");

        Donor donor = donorRepository.getDonorByUsernamePassword(username, password);

        if (donor != null) {
            result.put("result", true);
            result.put("donor", donor);
        } else {
            result.put("result", false);
            result.put("message", "Invalid username or password");
        }

        return result;
    }


//    @Autowired
//    ContactusRepository contactusRepository;


    @Autowired
    DonationRepository donationRepository;

    @Autowired
    BloodbankRepository bloodbankRepository;

    @PostMapping("/donation")
    Map<String, Object> donation(@RequestBody Map<String, Object> request, @RequestHeader("TOKEN") String token) throws IllegalAccessException
    {

        Integer bloodbankid = (Integer) request.get("bloodbank");
        String regdate = (String) request.get("regdate");
        String regtime = (String) request.get("regtime");


        if (token == null) {
            throw new IllegalAccessException();
        }
        Donor donor = donorRepository.findByToken(token).orElseThrow();


        Bloodbank bloodbank = bloodbankRepository.findById(bloodbankid).get();

        Donation a = new Donation();
        a.setBloodbank(bloodbank);
        a.setDonor(donor);
        a.setRegdate(regdate);
        a.setRegtime(regtime);
        a.setStatus("Y");

        donationRepository.save(a);

        Map<String,Object> result=new HashMap<>();
        result.put("Your donation is scheduled successfully", true);
        result.put("donor", a);
        return result;
    }

    //cancelDonation  - TOKEN, donatationid  -> status="CANCELLED"  performed by donor

    @PostMapping("/canceldonation")
    Map<String, Object> canceldonation(@RequestBody Map<String, Object> request, @RequestHeader("TOKEN") String token) throws IllegalAccessException
    {
        if(token==null)
        {
            throw new IllegalAccessException();
        }

        Donor donor = donorRepository.findByToken(token).orElseThrow();
        int donationid=(Integer)request.get("donationid");
        Donation a = donationRepository.findById(donationid).orElseThrow();

        if(a.getDonor().getId()!=donor.getId())
        {
            throw new IllegalAccessException();
        }
        a.setStatus("CANCELLED");

        donationRepository.save(a);

        Map<String,Object> result=new HashMap<>();
        result.put("Your donation is cancelled successfully", true);
//        result.put("donation", a);
        return result;


    }

    //getAllDonations  - TOKEN, status     performed by bloodbankuser
    {
        Bloodbankuser user=null; //get from token
        int bbid=user.getBloodbank().getId();
        List<Donation> list=donationRepository.findByBloodbankid(bbid);

        return list;
    }



    //setDonationStatus  - TOKEN, donationid, newstatus   perf by bloodbankuser

}
