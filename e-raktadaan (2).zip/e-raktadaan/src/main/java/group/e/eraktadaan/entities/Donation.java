package group.e.eraktadaan.entities;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "donation", indexes = {
        @Index(name = "donor", columnList = "donor"),
        @Index(name = "bloodbank", columnList = "bloodbank")
})
public class Donation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "donationid", nullable = true)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "donor", nullable = true)
    private Donor donor;

    @ManyToOne
    @JoinColumn(name = "bloodbank", nullable = true)
    private Bloodbank bloodbank;

    @Column(name = "regdate", nullable = true)
    private String regdate;

    @Column(name = "regtime", nullable = true)
    private String regtime;

    @Column(name = "donateddatetime", nullable = true)
    private Instant donateddatetime;

    @Lob
    @Column(name = "status", nullable = true)
    private String status;

    @Column(name = "comment", nullable = true)
    private String comment;

    public String getStatus() {
        return status;
    }

        public String getComment() {
            return comment;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public void setComment(String comment) {
        this.comment = comment;
    }


    public Instant getDonateddatetime() {
        return donateddatetime;
    }

    public void setDonateddatetime(Instant donateddatetime) {
        this.donateddatetime = donateddatetime;
    }


    public String getRegdate() {
        return regdate;
    }

    public void setRegdate(String regdate) {
        this.regdate = regdate;
    }

    public String getRegtime() {
        return regtime;
    }

    public void setRegtime(String regtime) {
        this.regtime = regtime;
    }

    public Bloodbank getBloodbank() {
        return bloodbank;
    }

    public void setBloodbank(Bloodbank bloodbank) {
        this.bloodbank = bloodbank;
    }

    public Donor getDonor() {
        return donor;
    }

    public void setDonor(Donor donor) {
        this.donor = donor;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}