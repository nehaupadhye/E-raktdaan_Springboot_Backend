package group.e.eraktadaan.entities;

import javax.persistence.*;
import java.time.Instant;
import java.time.LocalTime;

@Entity
@Table(name = "donorreply", indexes = {
        @Index(name = "bloodrequest", columnList = "bloodrequest"),
        @Index(name = "donor", columnList = "donor")
})
public class Donorreply {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "donorreplyid", nullable = false)
    private Integer id;

    @Column(name = "bloodrequest", nullable = false)
    private Integer bloodrequest;

    @Column(name = "donor", nullable = false)
    private Integer donor;

    @Column(name = "datetime", nullable = false)
    private Instant datetime;

    @Lob
    @Column(name = "reply", nullable = false)
    private String reply;

    @Column(name = "estimatedarrivaltime", nullable = false)
    private LocalTime estimatedarrivaltime;

    @Lob
    @Column(name = "isselected", nullable = false)
    private String isselected;

    public String getIsselected() {
        return isselected;
    }

    public void setIsselected(String isselected) {
        this.isselected = isselected;
    }

    public LocalTime getEstimatedarrivaltime() {
        return estimatedarrivaltime;
    }

    public void setEstimatedarrivaltime(LocalTime estimatedarrivaltime) {
        this.estimatedarrivaltime = estimatedarrivaltime;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public Instant getDatetime() {
        return datetime;
    }

    public void setDatetime(Instant datetime) {
        this.datetime = datetime;
    }

    public Integer getDonor() {
        return donor;
    }

    public void setDonor(Integer donor) {
        this.donor = donor;
    }

    public Integer getBloodrequest() {
        return bloodrequest;
    }

    public void setBloodrequest(Integer bloodrequest) {
        this.bloodrequest = bloodrequest;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}