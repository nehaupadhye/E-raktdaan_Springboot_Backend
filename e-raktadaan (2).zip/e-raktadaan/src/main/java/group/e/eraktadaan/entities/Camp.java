package group.e.eraktadaan.entities;

import javax.persistence.*;
import java.time.LocalTime;

@Entity
@Table(name = "camp", indexes = {
        @Index(name = "bloodbank", columnList = "bloodbank")
})
public class Camp {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "campid", nullable = false)
    private Integer id;

    @Column(name = "bloodbank", nullable = false)
    private Integer bloodbank;

    @Column(name = "datetime", nullable = false)
    private LocalTime datetime;

    @Lob
    @Column(name = "location", nullable = false)
    private String location;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalTime getDatetime() {
        return datetime;
    }

    public void setDatetime(LocalTime datetime) {
        this.datetime = datetime;
    }

    public Integer getBloodbank() {
        return bloodbank;
    }

    public void setBloodbank(Integer bloodbank) {
        this.bloodbank = bloodbank;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}