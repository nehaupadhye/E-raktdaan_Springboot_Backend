package group.e.eraktadaan.controllers;


import group.e.eraktadaan.entities.Bloodbankuser;
import group.e.eraktadaan.entities.Bloodbank;
import group.e.eraktadaan.repository.BloodbankuserRepository;
import group.e.eraktadaan.repository.BloodbankRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
public class BloodbankuserController {

    @Autowired
    BloodbankRepository bloodbankRepository;

    @Autowired
    BloodbankuserRepository bloodbankuserRepository;

    @PostMapping("/addbloodbankuser")
    Map<String, Object> addBloodbankuser(@RequestBody Map<String, Object> request) {
        Map<String, Object> result = new HashMap<>();

        String name = (String) request.get("name");
        String username = (String) request.get("username");
        String password = (String) request.get("password");
        Integer bbid=(Integer)request.get("bloodbankid");

        Bloodbankuser a=new Bloodbankuser();
        a.setName(name);
        a.setUsername(username);
        a.setPassword(password);
        a.setActive("Y");

        Bloodbank bb=bloodbankRepository.findById(bbid).get();
        a.setBloodbank(bb);

        bloodbankuserRepository.save(a);

        result.put("result", true);
        result.put("bloodbankuser",a);

        return result;
    }

    @PostMapping("/bloodbankuserlogin")
    Map<String, Object> login(@RequestBody Map<String, Object> request)
    {
        Map<String, Object> result=new HashMap<>();

        String name=(String)request.get("name");
        String username=(String)request.get("username");
        String password=(String)request.get("password");

        Bloodbankuser bloodbankuser=bloodbankuserRepository.getBloodbankuserByUsernamePassword(username, password);

        if(bloodbankuser!=null)
        {
            result.put("result", true);
            result.put("bloodbankuser",bloodbankuser);
        }
        else
        {
            result.put("result", false);
            result.put("message", "Invalid username or password");
        }

        return result;
    }

}
