package group.e.eraktadaan.repository;


import group.e.eraktadaan.entities.Bloodbankuser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BloodbankuserRepository extends JpaRepository<Bloodbankuser, Integer>{
    @Query("select a from Bloodbankuser a where a.username=:username and a.password=:password")  //hql
    public Bloodbankuser getBloodbankuserByUsernamePassword(String username, String password);



}

