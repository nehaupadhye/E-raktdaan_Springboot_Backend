//package group.e.eraktadaan.entities;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Lob;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "contactus")
//public class Contactus {
//    @Lob
//    @Column(name = "FirstName", nullable = false)
//    private String firstName;
//
//    @Lob
//    @Column(name = "LastName", nullable = false)
//    private String lastName;
//
//    @Lob
//    @Column(name = "Email", nullable = false)
//    private String email;
//
//    @Lob
//    @Column(name = "Subject", nullable = false)
//    private String subject;
//
//    @Lob
//    @Column(name = "Query", nullable = false)
//    private String query;
//
//    public String getQuery() {
//        return query;
//    }
//
//    public void setQuery(String query) {
//        this.query = query;
//    }
//
//    public String getSubject() {
//        return subject;
//    }
//
//    public void setSubject(String subject) {
//        this.subject = subject;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    public String getLastName() {
//        return lastName;
//    }
//
//    public void setLastName(String lastName) {
//        this.lastName = lastName;
//    }
//
//    public String getFirstName() {
//        return firstName;
//    }
//
//    public void setFirstName(String firstName) {
//        this.firstName = firstName;
//    }
//}