package group.e.eraktadaan.util;

public class util {

    public static String generateToken()
    {
        return "";
    }
}
