package group.e.eraktadaan.entities;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "bloodrequest", indexes = {
        @Index(name = "bloodbank", columnList = "bloodbank")
})
public class Bloodrequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bloodrequestid", nullable = false)
    private Integer id;

    @Column(name = "bloodbank", nullable = false)
    private Integer bloodbank;

    @Column(name = "bloodgroup", nullable = false, length = 2)
    private String bloodgroup;

    @Lob
    @Column(name = "rhfactor", nullable = false)
    private String rhfactor;

    @Column(name = "datetime", nullable = false)
    private Instant datetime;

    @Lob
    @Column(name = "isurgent", nullable = false)
    private String isurgent;

    @Lob
    @Column(name = "isnotificationsent", nullable = false)
    private String isnotificationsent;

    public String getIsnotificationsent() {
        return isnotificationsent;
    }

    public void setIsnotificationsent(String isnotificationsent) {
        this.isnotificationsent = isnotificationsent;
    }

    public String getIsurgent() {
        return isurgent;
    }

    public void setIsurgent(String isurgent) {
        this.isurgent = isurgent;
    }

    public Instant getDatetime() {
        return datetime;
    }

    public void setDatetime(Instant datetime) {
        this.datetime = datetime;
    }

    public String getRhfactor() {
        return rhfactor;
    }

    public void setRhfactor(String rhfactor) {
        this.rhfactor = rhfactor;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public Integer getBloodbank() {
        return bloodbank;
    }

    public void setBloodbank(Integer bloodbank) {
        this.bloodbank = bloodbank;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}