package group.e.eraktadaan.entities;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "donor")
public class Donor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "donorid", nullable = false)
    private Integer id;

    @Column(name = "donorname", nullable = false)
    private String donorname;

    @Lob
    @Column(name = "donoraddress", nullable = false)
    private String donoraddress;

    @Column(name = "mobileno", nullable = false)
    private String mobileno;


    @Lob
    @Column(name = "username", nullable = false)
    private String username;


    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "active", nullable = false, length = 5)
    private String active;

    @Column(name = "dob", nullable = false)
    private String dob;

    @Lob
    @Column(name = "dobnotification", nullable = false)
    private String dobnotification;

    @Lob
    @Column(name = "bloodgroup", nullable = false)
    private String bloodgroup;

    @Lob
    @Column(name = "rhfactor", nullable = false)
    private String rhfactor;

    @Column(name = "candonate", nullable = false, length = 5)
    private String candonate;

    @Column(name = "token")
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getCandonate() {
        return candonate;
    }

    public void setCandonate(String candonate) {
        this.candonate = candonate;
    }

    public String getRhfactor() {
        return rhfactor;
    }

    public void setRhfactor(String rhfactor) {
        this.rhfactor = rhfactor;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public String getDobnotification() {
        return dobnotification;
    }

    public void setDobnotification(String dobnotification) {
        this.dobnotification = dobnotification;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getDonoraddress() {
        return donoraddress;
    }

    public void setDonoraddress(String donoraddress) {
        this.donoraddress = donoraddress;
    }

    public String getDonorname() {
        return donorname;
    }

    public void setDonorname(String donorname) {
        this.donorname = donorname;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}