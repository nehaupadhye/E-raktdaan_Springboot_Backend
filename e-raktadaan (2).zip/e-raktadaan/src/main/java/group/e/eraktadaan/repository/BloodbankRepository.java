package group.e.eraktadaan.repository;

import group.e.eraktadaan.entities.Bloodbank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BloodbankRepository extends JpaRepository<Bloodbank, Integer> {
}


