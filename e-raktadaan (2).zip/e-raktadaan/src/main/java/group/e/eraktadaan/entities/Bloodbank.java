package group.e.eraktadaan.entities;

import javax.persistence.*;

@Entity
@Table(name = "bloodbank")
public class Bloodbank {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bloodbankid", nullable = false)
    private Integer id;

    @Column(name = "bloodbankname", nullable = false)
    private String bloodbankname;

    @Lob
    @Column(name = "bloodbankaddress", nullable = false)
    private String bloodbankaddress;

    @Lob
    @Column(name = "contact", nullable = false)
    private String contact;

    @Lob
    @Column(name = "active", nullable = false)
    private String active;

    public Bloodbank() {
    }

    public Bloodbank(Integer id) {
        this.id = id;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getBloodbankaddress() {
        return bloodbankaddress;
    }

    public void setBloodbankaddress(String bloodbankaddress) {
        this.bloodbankaddress = bloodbankaddress;
    }

    public String getBloodbankname() {
        return bloodbankname;
    }

    public void setBloodbankname(String bloodbankname) {
        this.bloodbankname = bloodbankname;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}