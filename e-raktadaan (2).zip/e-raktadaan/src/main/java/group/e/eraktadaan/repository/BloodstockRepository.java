package group.e.eraktadaan.repository;

import group.e.eraktadaan.entities.Bloodstock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface BloodstockRepository extends JpaRepository<Bloodstock, Integer>
{
    @Query("select bs from Bloodstock bs where bs.bloodbank.id=:bbid")
    public List<Bloodstock> getBloodStock(int bbid);
}
