package group.e.eraktadaan.repository;

public interface CampRepository {
}
