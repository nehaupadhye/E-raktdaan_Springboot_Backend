package group.e.eraktadaan.repository;

import group.e.eraktadaan.entities.Donor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ContactusRepository {
}




