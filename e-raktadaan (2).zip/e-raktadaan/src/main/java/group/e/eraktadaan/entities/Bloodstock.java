package group.e.eraktadaan.entities;

import javax.persistence.*;

@Entity
@Table(name = "bloodstock", indexes = {
        @Index(name = "bloodbank", columnList = "bloodbank")
})
public class Bloodstock {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bloodstockid", nullable = false)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "bloodbank", nullable = false)
    private Bloodbank bloodbank;

    @Lob
    @Column(name = "bloodstockname", nullable = false)
    private String bloodstockname;

    @Lob
    @Column(name = "quantity", nullable = false)
    private String quantity;

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getBloodstockname() {
        return bloodstockname;
    }

    public void setBloodstockname(String bloodstockname) {
        this.bloodstockname = bloodstockname;
    }

    public Bloodbank getBloodbank() {
        return bloodbank;
    }

    public void setBloodbank(Bloodbank bloodbank) {
        this.bloodbank = bloodbank;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}