package group.e.eraktadaan.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import group.e.eraktadaan.entities.User;

@RestController
public class HelloController {


	@GetMapping("/user")
	public User hello(String username)   //// ApplicationContext, HttpSession, HttpServletRequest, @RequestParam, @PathVariable, @RequestHeader
	{
		User u=new User();
		u.setUserid(1234);
		u.setName("abcde");
		
		return u;
	}

	@GetMapping("/users")
	public List<User> hello()
	{
		List<User> users=new ArrayList<>();
		
		User u1=new User();
		u1.setUserid(1234);
		u1.setName("abcde");
		
		User u2=new User();
		u2.setUserid(1234);
		u2.setName("abcde");
		
		users.add(u1);
		users.add(u2);
		
		return users;
	}
	
	@GetMapping("/login")
	public String login(HttpSession session, String username)
	{
		session.setAttribute("name", username);
		
		return "";
	}

	@GetMapping("/home")
	public String home(HttpSession session)
	{
		String name=(String)session.getAttribute("name");
		
		return "Welcome, "+name;
	}
	
	@GetMapping("/viewtoken")
	public String viewToken(@RequestHeader("TOKEN") String token)
	{
		return "Token is :"+token;
	}
	
	@PostMapping("/adduser")
	User addUser(@RequestBody User user)
	{
		System.out.println(user);

		return user;
	}


	@PostMapping("/reg")
	Map<String, Object> reg(@RequestBody Map<String, Object> request)
	{
		Map<String, Object> result=new HashMap<>();

		String username=(String)request.get("username");
		String password=(String)request.get("password");

		if("abcd".equals(username) && "efgh".equals(password))
		{
			result.put("result", true);
		}
		else
		{
			result.put("result", false);
			result.put("message", "Invalid username or password");
		}

		return result;
	}
	@PostMapping("/login")
	Map<String, Object> login(@RequestBody Map<String, Object> request)
	{
		Map<String, Object> result=new HashMap<>();
		
		String username=(String)request.get("username");
		String password=(String)request.get("password");

		if("abcd".equals(username) && "efgh".equals(password))
		{
			result.put("result", true);
		}
		else
		{
			result.put("result", false);
			result.put("message", "Invalid username or password");
		}
		
		return result;
	}
}
