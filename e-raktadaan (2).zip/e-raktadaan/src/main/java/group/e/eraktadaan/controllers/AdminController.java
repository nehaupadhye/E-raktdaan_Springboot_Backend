package group.e.eraktadaan.controllers;

import group.e.eraktadaan.entities.Admin;
import group.e.eraktadaan.entities.Bloodstock;
import group.e.eraktadaan.entities.User;
import group.e.eraktadaan.repository.AdminRepository;
import group.e.eraktadaan.repository.BloodstockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class AdminController {

    @Autowired
    AdminRepository adminRepository;

//    @GetMapping("/admin")
//    public User hello(String username)   //// ApplicationContext, HttpSession, HttpServletRequest, @RequestParam, @PathVariable, @RequestHeader
//    {
//        User u=new User();
//        u.setUserid(1234);
//        u.setName("abcde");
//
//        return u;
//    }

    @PostMapping("/addadmin")
    Map<String, Object> addAdmin(@RequestBody Map<String, Object> request) {
        Map<String, Object> result = new HashMap<>();

        String name = (String) request.get("name");
        String username = (String) request.get("username");
        String password = (String) request.get("password");

        Admin a=new Admin();
        a.setAdminname(name);
        a.setUsername(username);
        a.setPassword(password);
        a.setActive("Y");

        adminRepository.save(a);

        result.put("result", true);
        result.put("admin",a);

        return result;
    }

        @PostMapping("/adminlogin")
    Map<String, Object> login(@RequestBody Map<String, Object> request)
    {
        Map<String, Object> result=new HashMap<>();

        String username=(String)request.get("username");
        String password=(String)request.get("password");

        Admin admin=adminRepository.getAdminByUsernamePassword(username, password);

        if(admin!=null)
        {
            result.put("result", true);
            result.put("admin",admin);
        }
        else
        {
            result.put("result", false);
            result.put("message", "Invalid username or password");
        }

        return result;
    }


    @Autowired
    BloodstockRepository BloodstockRepository;

    @GetMapping("/bloodstock")
    public Map<String, Object> getBloodStock(Integer bbid)
    {
        List<Bloodstock> list=BloodstockRepository.getBloodStock(bbid);
        Map<String, Object> map=new HashMap<>();

        map.put("bloodstock",list);

        return map;
    }




}
