package group.e.eraktadaan.repository;

import group.e.eraktadaan.entities.Donor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;


public interface DonorRepository extends JpaRepository<Donor, Integer>
{
    @Query("select a from Donor a where a.username=:username and a.password=:password")  //hql
    public Donor getDonorByUsernamePassword(String username, String password);


    Optional<Donor> findByToken(String token);
}

