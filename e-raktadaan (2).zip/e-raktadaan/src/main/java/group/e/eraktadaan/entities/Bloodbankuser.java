package group.e.eraktadaan.entities;

import javax.persistence.*;

@Entity
@Table(name = "bloodbankuser", indexes = {
        @Index(name = "bloodbank", columnList = "bloodbank, username", unique = true)
})
public class Bloodbankuser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bloodbankuserid", nullable = false)
    private Integer id;

    @JoinColumn(name = "bloodbank", nullable = false)
    @ManyToOne
    private Bloodbank bloodbank;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "username", nullable = false)
    private String username;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "active", nullable = false)
    private String active;

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {this.name = name;}

    public Bloodbank getBloodbank() {
        return bloodbank;
    }

    public void setBloodbank(Bloodbank bloodbank) {
        this.bloodbank = bloodbank;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}