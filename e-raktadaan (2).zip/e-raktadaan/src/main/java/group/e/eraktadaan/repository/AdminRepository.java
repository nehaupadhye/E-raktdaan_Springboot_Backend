package group.e.eraktadaan.repository;

import group.e.eraktadaan.entities.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AdminRepository extends JpaRepository<Admin, Integer>
{
    @Query("select a from Admin a where a.username=:username and a.password=:password")  //hql
    public Admin getAdminByUsernamePassword(String username, String password);
}
